<html>
    <head>
        <title>PROGRAM PENJUMLAHAN</title>
    </head>
    <body>
        <form method="POST" action="Tugas1.php">
            <p>Nilai A adalah : <input type="text" name="nilaiA" size="5"></p>
            <p>Nilai B adalah : <input type="text" name="nilaiB" size="5"></p>
            <p><input type="submit" value="Jumlahkan" name="jumlah"></p>
        </form></br>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST"){
            error_reporting (E_ALL ^ E_NOTICE);
            $nilaiA = $_POST["nilaiA"];
            $nilaiB = $_POST["nilaiB"];
            $jumlah = $nilaiA + $nilaiB;

            if($jumlah){
                echo "Nilai A adalah $nilaiA</br>";
                echo "Nilai B adalah $nilaiB</br>";
                echo "Jadi Nilai A ditambah Nilai B adalah $jumlah";
            }
        }
        ?>
    </body>
</html>